<?php
echo "<form action='Login/access' method='post'>";
echo "<label> User name :</label>";
echo "<input name='username' type='email' required/> <br>";
echo "<label> Password :</label>";
echo "<input name='password' type='password' required/> <br>";
echo "<input type='submit' value='login'/>";
echo "</form>";

?>