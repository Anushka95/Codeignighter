<h1> header </h1>
<?=$ti."\n"?>
<?=$ti2."\n"?>
<?=$mda."\n"?>