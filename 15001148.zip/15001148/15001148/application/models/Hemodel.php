<?php
class Hemodel extends CI_Model{
	public function getM(){
		return "dzf";
	}
}
?>